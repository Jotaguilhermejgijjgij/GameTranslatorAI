plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gametranslator.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gametranslator.ai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-mvp"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Corrotinas, usadas para orquestrar captura -> OCR -> tradução -> overlay
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // OCR on-device (gratuito, sem chave de API, sem dependência de nuvem)
    implementation("com.google.mlkit:text-recognition:16.0.0")

    // Tradução on-device (gratuita, sem chave de API). Implementa a
    // interface TranslationAgent, então pode ser substituída depois por
    // um agente baseado em LLM sem mudar o resto do app.
    implementation("com.google.mlkit:translate:17.0.3")
}
