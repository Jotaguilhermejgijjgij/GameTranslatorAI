package com.gametranslator.ai.translate

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Implementação padrão do agente de tradução, usando o modelo on-device
 * do ML Kit (Google). Funciona offline após o download inicial do modelo,
 * é gratuita e não exige nenhuma chave de API embutida no app.
 *
 * Como implementa a interface TranslationAgent, pode ser substituída no
 * futuro por um agente baseado em um modelo de linguagem (LLM) mais
 * sofisticado, capaz de entender contexto de forma mais rica, sem alterar
 * o restante do aplicativo.
 */
class MlKitTranslationAgent(
    private val cache: TranslationCache
) : TranslationAgent {

    private var translator: Translator? = null

    // Glossário simples em memória: mantém nomes próprios (personagens,
    // itens, locais) consistentes entre chamadas, sem traduzi-los.
    private val glossary: MutableMap<String, String> = mutableMapOf()

    override suspend fun prepare(sourceLanguage: String) {
        val sourceCode = TranslateLanguage.fromLanguageTag(sourceLanguage) ?: TranslateLanguage.ENGLISH
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceCode)
            .setTargetLanguage(TranslateLanguage.PORTUGUESE)
            .build()
        val newTranslator = Translation.getClient(options)
        translator = newTranslator

        val conditions = DownloadConditions.Builder().build()
        suspendCancellableCoroutine<Unit> { cont ->
            newTranslator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener { if (cont.isActive) cont.resume(Unit) }
                .addOnFailureListener { e -> if (cont.isActive) cont.resumeWithException(e) }
        }
    }

    override suspend fun translate(text: String, contextHint: String?): String {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return ""

        cache.get(trimmed)?.let { return it }
        glossary[trimmed.lowercase()]?.let { return it }

        if (looksLikeProperNoun(trimmed)) {
            glossary[trimmed.lowercase()] = trimmed
            cache.put(trimmed, trimmed)
            return trimmed
        }

        val currentTranslator = translator
            ?: throw IllegalStateException("Chame prepare() antes de translate()")

        val result = suspendCancellableCoroutine<String> { cont ->
            currentTranslator.translate(trimmed)
                .addOnSuccessListener { translated -> if (cont.isActive) cont.resume(translated) }
                .addOnFailureListener { e -> if (cont.isActive) cont.resumeWithException(e) }
        }

        cache.put(trimmed, result)
        return result
    }

    override fun release() {
        translator?.close()
        translator = null
    }

    /**
     * Heurística simples: textos curtos, em Title Case e sem verbos comuns
     * tendem a ser nomes próprios de itens, personagens ou locais, e não
     * devem ser traduzidos literalmente.
     */
    private fun looksLikeProperNoun(text: String): Boolean {
        val words = text.split(" ").filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 4) return false
        val allCapitalized = words.all { it.first().isUpperCase() }
        val hasCommonVerb = text.lowercase()
            .matches(Regex(".*\\b(is|are|was|were|has|have|do|does|will|can|the|a|an)\\b.*"))
        return allCapitalized && !hasCommonVerb
    }
}
