package com.gametranslator.ai

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CompoundButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Switch
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.gametranslator.ai.model.AppMode
import com.gametranslator.ai.service.TranslationService
import com.gametranslator.ai.settings.AppPreferences

/**
 * Tela inicial: fluxo de permissões (overlay + captura de tela) e
 * controles principais (modo, ativar/desativar IA, iniciar/parar).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: AppPreferences
    private var isTranslating = false

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, TranslationService::class.java).apply {
                putExtra(TranslationService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(TranslationService.EXTRA_DATA, result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            isTranslating = true
            updateStartButtonLabel()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = AppPreferences(this)

        val sourceLangSpinner = findViewById<Spinner>(R.id.spinnerSourceLang)
        val modeGroup = findViewById<RadioGroup>(R.id.radioGroupMode)
        val aiSwitch = findViewById<Switch>(R.id.switchAiEnabled)
        val startButton = findViewById<Button>(R.id.btnStart)
        val settingsButton = findViewById<Button>(R.id.btnSettings)

        // Versão inicial só suporta inglês como idioma de origem.
        sourceLangSpinner.setSelection(0)
        prefs.sourceLanguage = "en"

        modeGroup.check(if (prefs.mode == AppMode.AUTOMATIC) R.id.radioAuto else R.id.radioManual)
        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            prefs.mode = if (checkedId == R.id.radioAuto) AppMode.AUTOMATIC else AppMode.MANUAL
        }

        aiSwitch.isChecked = prefs.aiEnabled
        aiSwitch.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
            prefs.aiEnabled = checked
        }

        startButton.setOnClickListener {
            if (isTranslating) {
                stopService(Intent(this, TranslationService::class.java))
                isTranslating = false
                updateStartButtonLabel()
            } else {
                requestPermissionsAndStart()
            }
        }

        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        updateStartButtonLabel()
    }

    private fun updateStartButtonLabel() {
        findViewById<Button>(R.id.btnStart).text =
            getString(if (isTranslating) R.string.btn_stop else R.string.btn_start)
    }

    private fun requestPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
