package com.gametranslator.ai.translate

import com.gametranslator.ai.model.TextBlock

/**
 * Compara o texto detectado no quadro atual com o do quadro anterior para
 * evitar reprocessar a mesma tela repetidamente.
 */
class ChangeDetector {
    private var lastSignature: String = ""
    private var lastTextsById: MutableMap<String, String> = mutableMapOf()

    /** Retorna apenas os blocos cujo texto mudou desde a última chamada. */
    fun changedBlocks(blocks: List<TextBlock>): List<TextBlock> {
        val signature = blocks.joinToString("|") { it.originalText }
        if (signature == lastSignature) return emptyList()

        val changed = blocks.filter { block -> lastTextsById[block.id] != block.originalText }

        lastSignature = signature
        lastTextsById = blocks.associate { it.id to it.originalText }.toMutableMap()
        return changed
    }

    fun reset() {
        lastSignature = ""
        lastTextsById.clear()
    }
}
