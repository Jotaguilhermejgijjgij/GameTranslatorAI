package com.gametranslator.ai.model

import android.graphics.Rect

data class TextBlock(
    val id: String,
    val originalText: String,
    val boundingBox: Rect
)

data class TranslatedBlock(
    val id: String,
    val originalText: String,
    val translatedText: String,
    val boundingBox: Rect
)
