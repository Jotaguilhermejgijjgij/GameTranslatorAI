package com.gametranslator.ai.model

enum class AppMode { AUTOMATIC, MANUAL }
