package com.gametranslator.ai.ocr

import android.graphics.Bitmap
import com.gametranslator.ai.model.TextBlock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Extrai blocos de texto de um bitmap da tela usando o reconhecedor de
 * texto on-device do ML Kit (gratuito, sem chave de API).
 */
class OcrProcessor {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(bitmap: Bitmap): List<TextBlock> {
        val image = InputImage.fromBitmap(bitmap, 0)

        val visionText = suspendCancellableCoroutine<Text> { cont ->
            recognizer.process(image)
                .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                .addOnFailureListener { e -> if (cont.isActive) cont.resumeWithException(e) }
        }

        return visionText.textBlocks.mapIndexedNotNull { index, block ->
            val box = block.boundingBox ?: return@mapIndexedNotNull null
            val text = block.text.trim()
            if (text.isEmpty()) return@mapIndexedNotNull null
            TextBlock(id = "block_$index", originalText = text, boundingBox = box)
        }
    }

    fun release() {
        recognizer.close()
    }
}
