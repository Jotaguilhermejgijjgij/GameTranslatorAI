package com.gametranslator.ai.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.gametranslator.ai.model.TranslatedBlock
import com.gametranslator.ai.settings.AppPreferences

/**
 * Desenha as caixas de tradução por cima da tela usando uma janela de
 * overlay. Requer a permissão "Exibir sobre outros apps" concedida pelo
 * usuário (SYSTEM_ALERT_WINDOW). Posição, tamanho e transparência são
 * lidos das preferências, que a tela de Configurações altera.
 */
class OverlayManager(
    private val context: Context,
    private val prefs: AppPreferences
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val activeViews = mutableMapOf<String, TextView>()

    fun showTranslations(blocks: List<TranslatedBlock>) {
        val idsToRemove = activeViews.keys - blocks.map { it.id }.toSet()
        idsToRemove.forEach { removeBlock(it) }

        blocks.forEach { block ->
            val existing = activeViews[block.id]
            if (existing != null) {
                existing.text = block.translatedText
                updatePosition(existing, block)
            } else {
                addBlock(block)
            }
        }
    }

    private fun addBlock(block: TranslatedBlock) {
        val textView = TextView(context).apply {
            text = block.translatedText
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(prefs.overlayOpacityPercent * 255 / 100, 0, 0, 0))
            textSize = 12f * (prefs.overlayTextScalePercent / 100f)
            setPadding(12, 6, 12, 6)
        }

        val params = WindowManager.LayoutParams(
            block.boundingBox.width(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = block.boundingBox.left
            y = block.boundingBox.top
        }

        try {
            windowManager.addView(textView, params)
            activeViews[block.id] = textView
        } catch (e: Exception) {
            // Permissão de overlay ausente ou revogada; ignora silenciosamente.
        }
    }

    private fun updatePosition(view: TextView, block: TranslatedBlock) {
        val params = view.layoutParams as? WindowManager.LayoutParams ?: return
        params.x = block.boundingBox.left
        params.y = block.boundingBox.top
        params.width = block.boundingBox.width()
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) { }
    }

    private fun removeBlock(id: String) {
        activeViews.remove(id)?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { }
        }
    }

    fun clearAll() {
        activeViews.keys.toList().forEach { removeBlock(it) }
    }

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
}
