package com.gametranslator.ai.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageButton
import androidx.core.app.NotificationCompat
import com.gametranslator.ai.R
import com.gametranslator.ai.capture.ScreenCaptureHelper
import com.gametranslator.ai.model.AppMode
import com.gametranslator.ai.model.TranslatedBlock
import com.gametranslator.ai.ocr.OcrProcessor
import com.gametranslator.ai.overlay.OverlayManager
import com.gametranslator.ai.settings.AppPreferences
import com.gametranslator.ai.translate.ChangeDetector
import com.gametranslator.ai.translate.MlKitTranslationAgent
import com.gametranslator.ai.translate.TranslationCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Serviço em 1º plano que coordena todo o fluxo:
 * captura de tela -> OCR -> detecção de mudança -> agente de IA -> overlay.
 *
 * Roda como foreground service (obrigatório para usar MediaProjection em
 * segundo plano) e mostra uma notificação persistente enquanto ativo.
 */
class TranslationService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private lateinit var prefs: AppPreferences
    private lateinit var captureHelper: ScreenCaptureHelper
    private lateinit var ocrProcessor: OcrProcessor
    private lateinit var overlayManager: OverlayManager
    private lateinit var translationAgent: MlKitTranslationAgent
    private val cache = TranslationCache()
    private val changeDetector = ChangeDetector()

    private var autoLoopJob: Job? = null
    private var floatingButtonView: ImageButton? = null
    private val windowManager by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }

    override fun onCreate() {
        super.onCreate()
        prefs = AppPreferences(this)
        captureHelper = ScreenCaptureHelper(this)
        ocrProcessor = OcrProcessor()
        overlayManager = OverlayManager(this, prefs)
        translationAgent = MlKitTranslationAgent(cache)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)

        if (data != null && resultCode == Activity.RESULT_OK) {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            captureHelper.start(resultCode, data, projectionManager)

            serviceScope.launch {
                translationAgent.prepare(prefs.sourceLanguage)
                withContext(Dispatchers.Main) {
                    if (prefs.mode == AppMode.MANUAL) showFloatingButton() else startAutoLoop()
                }
            }
        }

        return START_STICKY
    }

    private fun startAutoLoop() {
        autoLoopJob?.cancel()
        autoLoopJob = serviceScope.launch {
            while (isActive) {
                processOnce()
                delay(prefs.autoCaptureIntervalMs)
            }
        }
    }

    private fun showFloatingButton() {
        if (floatingButtonView != null) return
        val button = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_search)
            setOnClickListener { serviceScope.launch { processOnce() } }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 200
        }
        try {
            windowManager.addView(button, params)
            floatingButtonView = button
        } catch (e: Exception) { }
    }

    /** Um ciclo completo: captura -> OCR -> só traduz o que mudou -> overlay. */
    private suspend fun processOnce() {
        if (!prefs.aiEnabled) return
        val bitmap = captureHelper.captureFrame() ?: return
        val blocks = try {
            ocrProcessor.recognize(bitmap)
        } finally {
            bitmap.recycle()
        }

        val changed = changeDetector.changedBlocks(blocks)
        if (changed.isEmpty() && blocks.isEmpty()) {
            withContext(Dispatchers.Main) { overlayManager.clearAll() }
            return
        }

        val translated = blocks.map { block ->
            val text = translationAgent.translate(block.originalText)
            TranslatedBlock(block.id, block.originalText, text, block.boundingBox)
        }

        withContext(Dispatchers.Main) {
            overlayManager.showTranslations(translated)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "game_translator_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        autoLoopJob?.cancel()
        floatingButtonView?.let { try { windowManager.removeView(it) } catch (e: Exception) { } }
        overlayManager.clearAll()
        captureHelper.stop()
        ocrProcessor.release()
        translationAgent.release()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_DATA = "extra_data"
        private const val NOTIFICATION_ID = 1001
    }
}
