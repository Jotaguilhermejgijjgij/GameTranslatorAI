package com.gametranslator.ai.translate

/**
 * Contrato do agente de IA responsável pela tradução.
 *
 * A versão inicial (MlKitTranslationAgent) usa um modelo on-device
 * gratuito. No futuro, outra implementação (por exemplo, baseada em um
 * LLM via API) pode substituir esta sem alterar o resto do aplicativo.
 */
interface TranslationAgent {
    suspend fun prepare(sourceLanguage: String)
    suspend fun translate(text: String, contextHint: String? = null): String
    fun release()
}
