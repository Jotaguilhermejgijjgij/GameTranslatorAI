package com.gametranslator.ai.settings

import android.content.Context
import com.gametranslator.ai.model.AppMode

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("game_translator_prefs", Context.MODE_PRIVATE)

    var sourceLanguage: String
        get() = prefs.getString(KEY_SOURCE_LANG, "en") ?: "en"
        set(value) = prefs.edit().putString(KEY_SOURCE_LANG, value).apply()

    var mode: AppMode
        get() = AppMode.valueOf(prefs.getString(KEY_MODE, AppMode.MANUAL.name) ?: AppMode.MANUAL.name)
        set(value) = prefs.edit().putString(KEY_MODE, value.name).apply()

    var aiEnabled: Boolean
        get() = prefs.getBoolean(KEY_AI_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_AI_ENABLED, value).apply()

    var overlayOpacityPercent: Int
        get() = prefs.getInt(KEY_OVERLAY_OPACITY, 85)
        set(value) = prefs.edit().putInt(KEY_OVERLAY_OPACITY, value).apply()

    var overlayTextScalePercent: Int
        get() = prefs.getInt(KEY_OVERLAY_SCALE, 100)
        set(value) = prefs.edit().putInt(KEY_OVERLAY_SCALE, value).apply()

    /** Intervalo entre capturas no modo automático. Ajustável para poupar
     * processamento em aparelhos mais fracos. */
    var autoCaptureIntervalMs: Long
        get() = prefs.getLong(KEY_AUTO_INTERVAL, 1500L)
        set(value) = prefs.edit().putLong(KEY_AUTO_INTERVAL, value).apply()

    companion object {
        private const val KEY_SOURCE_LANG = "source_lang"
        private const val KEY_MODE = "mode"
        private const val KEY_AI_ENABLED = "ai_enabled"
        private const val KEY_OVERLAY_OPACITY = "overlay_opacity"
        private const val KEY_OVERLAY_SCALE = "overlay_scale"
        private const val KEY_AUTO_INTERVAL = "auto_interval"
    }
}
