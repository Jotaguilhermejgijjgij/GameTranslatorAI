package com.gametranslator.ai.translate

import android.util.LruCache

class TranslationCache(maxEntries: Int = 500) {
    private val cache = LruCache<String, String>(maxEntries)

    fun get(originalText: String): String? = cache.get(normalize(originalText))

    fun put(originalText: String, translatedText: String) {
        cache.put(normalize(originalText), translatedText)
    }

    private fun normalize(text: String): String = text.trim().lowercase()
}
