# Game Translator AI (v0.1 — MVP)

Tradutor de jogos em tempo real: captura a tela, reconhece texto em inglês (OCR)
e mostra a tradução em português do Brasil sobre o jogo, sem precisar sair dele.

## O que já funciona nesta versão

- Captura de tela via `MediaProjection` (sem salvar nenhum screenshot em disco).
- OCR on-device com ML Kit (Google), gratuito, sem chave de API.
- Tradução on-device com ML Kit (Google), gratuita, sem chave de API — funciona
  offline após o primeiro download do modelo (~30 MB, feito automaticamente).
- Heurística simples para não traduzir nomes próprios (personagens, itens, locais).
- Cache de traduções (evita retraduzir a mesma frase) + detecção de mudança de
  tela (evita reprocessar quando nada mudou).
- Overlay flutuante configurável (opacidade e tamanho do texto).
- Modo Automático (traduz continuamente) e Modo Manual (botão flutuante).
- Arquitetura modular (`capture`, `ocr`, `translate`, `overlay`, `settings`,
  `service`), pronta para depois trocar o agente de tradução por um LLM mais
  sofisticado sem mexer no resto do app (basta implementar `TranslationAgent`).

## Requisitos

- Android Studio (Koala ou mais recente)
- JDK 17 (o Android Studio já traz um embutido)
- Um celular Android real com Android 7.0 (API 24) ou superior, **ou** um
  emulador — mas emuladores costumam se comportar mal com `MediaProjection`,
  então um aparelho físico é recomendado para testar de verdade.

## Como abrir e executar

1. Abra o Android Studio → **Open** → selecione a pasta `GameTranslatorAI`.
2. Aguarde o **Gradle Sync** (o Android Studio baixa a wrapper do Gradle e as
   dependências automaticamente — é necessário estar com internet nesta etapa).
3. Conecte um celular Android via USB com a **depuração USB** ativada
   (Configurações → Sobre o telefone → toque 7x em "Número da versão" para
   habilitar Opções do desenvolvedor → ative "Depuração USB").
4. Clique em **Run ▶** com o dispositivo selecionado.

## Como testar

1. Abra o app **Game Translator AI**.
2. Escolha o modo **Automático** ou **Manual**.
3. Toque em **Iniciar tradução**.
4. Na primeira vez, o Android vai pedir a permissão **"Exibir sobre outros
   apps"** — conceda e volte ao app (toque em "Iniciar tradução" de novo).
5. Em seguida aparece o diálogo padrão do Android perguntando se o app pode
   **gravar/transmitir a tela** — toque em "Iniciar agora".
6. Abra o jogo em inglês.
   - **Modo Automático:** a tradução aparece e se atualiza sozinha.
   - **Modo Manual:** toque no botão flutuante (ícone de lupa) para traduzir
     a tela atual.
7. Em **Configurações**, dá para ajustar a opacidade e o tamanho da caixa de
   tradução.

> Na primeira tradução, o ML Kit baixa o modelo de tradução inglês→português
> (uma vez só, precisa de internet). Depois disso, tudo roda offline.

## Limitações conhecidas desta primeira versão (propositais)

- Só traduz de inglês para português (por enquanto).
- A posição do overlay é recalculada a cada ciclo; textos animados/rolando
  rápido podem ficar levemente atrasados.
- A tradução usa o modelo genérico do ML Kit — é boa, mas não tem o mesmo
  nível de entendimento de contexto de um LLM. Isso é intencional: a
  interface `TranslationAgent` já isola essa parte para facilitar a troca
  por um agente mais avançado depois.
- Sem histórico, sem dicionário personalizado, sem perfis por jogo ainda.

## Próximos passos sugeridos (não implementados ainda)

- Tradução de menus separada da tradução de diálogos (prioridades diferentes).
- Reconhecimento de contexto mais avançado (agente baseado em LLM, plugável
  via `TranslationAgent`, sem chave exposta no app — por exemplo, usando um
  backend próprio que guarda a chave).
- Histórico de traduções e dicionário/glossário editável pelo usuário.
- Perfis de configuração por jogo (regiões de tela, glossário, etc.).
- Reconhecimento de regiões específicas da tela (ex.: só a caixa de diálogo).
- Suporte a outros idiomas de origem.
